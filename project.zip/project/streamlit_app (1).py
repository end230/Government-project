# streamlit_app.py

import streamlit as st
from langchain_core.messages import HumanMessage, AIMessage

from gahar_chat_firestore_rag import GaharAssistant  # same folder as this file


st.set_page_config(page_title="GAHAR RAG Assistant", page_icon="🏥")
st.title("🏥 GAHAR Accreditation Assistant (RAG)")
st.write("Ask questions about the GAHAR Hospital Standards Handbook.")


# ---------------------------
#  INIT BACKEND IN SESSION
# ---------------------------
if "assistant" not in st.session_state:
    # You can customize session_id per user if you want
    st.session_state.assistant = GaharAssistant(session_id="streamlit-session")

assistant = st.session_state.assistant


# ---------------------------
#  SHOW CHAT HISTORY
# ---------------------------
history = assistant.get_history()

for msg in history:
    if isinstance(msg, HumanMessage):
        if not msg.content:
            continue
        with st.chat_message("user"):
            st.write(msg.content)
    elif isinstance(msg, AIMessage):
        if not msg.content:
            continue
        with st.chat_message("assistant"):
            st.write(msg.content)


# ---------------------------
#  CHAT INPUT
# ---------------------------
user_input = st.chat_input("Ask a GAHAR question...")

if user_input:
    # Show user message
    with st.chat_message("user"):
        st.write(user_input)

    # Get answer from backend
    answer = assistant.answer(user_input)

    # Show AI answer
    with st.chat_message("assistant"):
        st.write(answer)
