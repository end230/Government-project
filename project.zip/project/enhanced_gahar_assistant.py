"""
Enhanced GAHAR Assistant with Query Decomposition and XLM-RoBERTa
Integrates with your existing gahar_chat_firestore_rag.py
"""

import os
from dotenv import load_dotenv
from typing import Optional

from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import Docx2txtLoader
import glob

# Import new modules
from config import Config
from query_decomposer import QueryDecomposer, GAHARQueryExpander
from xlm_model_handler import XLMModelHandler

# Optional: Keep Gemini as fallback
try:
    from langchain_google_genai import ChatGoogleGenerativeAI
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("⚠️  Gemini not available. Using XLM only.")


class EnhancedGaharAssistant:
    """
    Enhanced GAHAR Assistant with:
    - Multilingual embeddings (paraphrase-multilingual-mpnet-base-v2)
    - XLM-RoBERTa instead of Gemini
    - Query decomposition for complex queries
    - Optional Gemini fallback
    """
    
    def __init__(
        self,
        session_id: str = "default-session",
        use_query_decomposition: bool = True,
        use_gemini_fallback: bool = False
    ):
        """
        Initialize Enhanced GAHAR Assistant
        
        Args:
            session_id: Session identifier
            use_query_decomposition: Enable query decomposition
            use_gemini_fallback: Use Gemini if XLM fails
        """
        print("🚀 Initializing Enhanced GAHAR Assistant")
        print(f"   Session: {session_id}")
        print(f"   Query Decomposition: {use_query_decomposition}")
        print(f"   Gemini Fallback: {use_gemini_fallback}")
        
        # Load environment variables
        current_dir = os.path.dirname(os.path.abspath(__file__))
        load_dotenv(os.path.join(current_dir, ".env"))
        
        # Initialize chat history
        self.chat_history = ChatMessageHistory()
        self.session_id = session_id
        
        # Initialize vector store with UPGRADED embeddings
        print("\n📊 Loading Vector Store...")
        self.db = self._init_vectorstore()
        
        # Initialize query decomposer
        self.use_query_decomposition = use_query_decomposition
        if use_query_decomposition:
            print("\n🔍 Initializing Query Decomposer...")
            self.query_decomposer = QueryDecomposer(
                max_sub_queries=Config.MAX_SUB_QUERIES
            )
            self.query_expander = GAHARQueryExpander()
        
        # Initialize XLM model
        print("\n🤖 Initializing XLM Model...")
        try:
            self.xlm_handler = XLMModelHandler(
                model_name=Config.XLM_MODEL_NAME,
                use_fine_tuned=Config.USE_FINE_TUNED_MODEL,
                fine_tuned_path=Config.FINE_TUNED_MODEL_PATH if Config.USE_FINE_TUNED_MODEL else None
            )
            self.xlm_available = True
        except Exception as e:
            print(f"   ⚠️  XLM initialization failed: {e}")
            self.xlm_available = False
        
        # Initialize Gemini fallback if requested
        self.use_gemini_fallback = use_gemini_fallback and GEMINI_AVAILABLE
        if self.use_gemini_fallback:
            print("\n🔄 Initializing Gemini Fallback...")
            try:
                self.gemini_model = ChatGoogleGenerativeAI(
                    model=Config.GEMINI_MODEL_NAME
                )
                print("   ✅ Gemini available as fallback")
            except Exception as e:
                print(f"   ⚠️  Gemini fallback failed: {e}")
                self.gemini_model = None
        else:
            self.gemini_model = None
        
        print("\n✅ Enhanced GAHAR Assistant Ready!")
    
    def _get_embeddings(self):
        """
        Get UPGRADED multilingual embeddings
        This replaces your old all-MiniLM-L6-v2 (English only)
        """
        print(f"   Loading embeddings: {Config.EMBEDDING_MODEL_NAME}")
        return HuggingFaceEmbeddings(
            model_name=Config.EMBEDDING_MODEL_NAME
        )
    
    def _init_vectorstore(self) -> Chroma:
        """
        Initialize or load vector store from Word documents
        Compatible with your existing structure
        """
        docs_path = Config.BOOKS_DIR  # Directory containing Word files
        persistent_directory = Config.CHROMA_DB_PATH
        
        os.makedirs(Config.DB_DIR, exist_ok=True)
        
        if not os.path.exists(docs_path):
            raise FileNotFoundError(
                f"Documents directory not found at: {docs_path}\n"
                f"Make sure 'books/' folder exists with .docx files."
            )
        
        embeddings = self._get_embeddings()
        
        # Check if vector store exists
        if not os.path.exists(persistent_directory):
            print("   📦 Building new vector store from Word documents...")
            
            # Load all Word documents from the directory
            word_files = glob.glob(os.path.join(docs_path, "*.docx"))
            
            if not word_files:
                raise FileNotFoundError(
                    f"No .docx files found in {docs_path}\n"
                    f"Please add Word documents to the 'books/' folder."
                )
            
            print(f"   📄 Found {len(word_files)} Word document(s)")
            
            # Load all documents
            all_documents = []
            for word_file in word_files:
                print(f"   📖 Loading: {os.path.basename(word_file)}")
                loader = Docx2txtLoader(word_file)
                docs = loader.load()
                all_documents.extend(docs)
            
            print(f"   ✅ Loaded {len(all_documents)} document(s)")
            
            # Split into chunks
            text_splitter = CharacterTextSplitter(
                chunk_size=Config.CHUNK_SIZE,
                chunk_overlap=Config.CHUNK_OVERLAP
            )
            docs = text_splitter.split_documents(all_documents)
            
            print(f"   📄 Processing {len(docs)} document chunks...")
            
            db = Chroma.from_documents(
                docs,
                embeddings,
                persist_directory=persistent_directory,
            )
            print("   ✅ Vector store created")
        else:
            print("   📂 Loading existing vector store...")
            db = Chroma(
                persist_directory=persistent_directory,
                embedding_function=embeddings,
            )
            print("   ✅ Vector store loaded")
        
        return db
    
    def _retrieve_context(self, query: str) -> str:
        """
        Retrieve context with optional query decomposition
        
        Args:
            query: User query
            
        Returns:
            Retrieved context text
        """
        if self.use_query_decomposition:
            # Decompose query
            decomposition = self.query_decomposer.decompose_query(query)
            
            if decomposition["is_complex"]:
                print(f"   🔍 Complex query detected")
                print(f"   📝 Sub-queries: {len(decomposition['sub_queries'])}")
                
                # Retrieve for each sub-query
                all_contexts = []
                for sub_query in decomposition["sub_queries"]:
                    docs = self.db.similarity_search(sub_query, k=Config.TOP_K_RETRIEVAL)
                    if docs:
                        context = "\n\n".join(doc.page_content for doc in docs)
                        all_contexts.append(context)
                
                # Merge contexts
                if all_contexts:
                    return self.query_decomposer.merge_contexts(all_contexts)[:4000]
        
        # Standard retrieval (no decomposition or simple query)
        docs = self.db.similarity_search(query, k=Config.TOP_K_RETRIEVAL)
        
        if not docs:
            return "No highly relevant context found in the GAHAR handbook."
        
        return "\n\n---\n\n".join(doc.page_content for doc in docs)[:4000]
    
    def answer(self, question: str) -> str:
        """
        Answer a GAHAR question using XLM model (or Gemini fallback)
        
        Args:
            question: User question
            
        Returns:
            Answer text
        """
        print(f"\n{'='*80}")
        print(f"❓ Question: {question}")
        print(f"{'='*80}")
        
        # Step 1: Retrieve context
        print("\n📚 Retrieving context...")
        context_text = self._retrieve_context(question)
        
        # Step 2: Generate answer
        print("\n💬 Generating answer...")
        
        # Try XLM first
        if self.xlm_available:
            try:
                print(f"   🤖 Using Local Model ({Config.XLM_MODEL_NAME})...")
                answer = self.xlm_handler.generate_answer(
                    question=question,
                    context=context_text,
                    system_prompt=Config.SYSTEM_PROMPT,
                    max_new_tokens=Config.MAX_NEW_TOKENS,
                    temperature=Config.TEMPERATURE,
                    top_p=Config.TOP_P
                )
                
                # Save to history
                self.chat_history.add_user_message(question)
                self.chat_history.add_ai_message(answer)
                
                print("   ✅ Answer generated with XLM")
                return answer
                
            except Exception as e:
                print(f"   ⚠️  XLM generation failed: {e}")
                
                # Fall back to Gemini if available
                if self.use_gemini_fallback and self.gemini_model:
                    print("   🔄 Falling back to Gemini...")
                    return self._answer_with_gemini(question, context_text)
                else:
                    return self._create_fallback_answer(question, context_text)
        
        # If XLM not available, use Gemini or fallback
        elif self.use_gemini_fallback and self.gemini_model:
            print("   🔄 Using Gemini (XLM not available)...")
            return self._answer_with_gemini(question, context_text)
        else:
            return self._create_fallback_answer(question, context_text)
    
    def _answer_with_gemini(self, question: str, context: str) -> str:
        """
        Answer using Gemini (your original method)
        
        Args:
            question: User question
            context: Retrieved context
            
        Returns:
            Answer text
        """
        from langchain_core.messages import HumanMessage, SystemMessage
        
        messages = []
        messages.append(SystemMessage(content=Config.SYSTEM_PROMPT))
        
        # Add history
        clean_history = [
            m for m in self.chat_history.messages
            if getattr(m, "content", None) not in (None, "")
        ]
        messages.extend(clean_history)
        
        # Add current question with context
        messages.append(
            HumanMessage(
                content=(
                    f"Context from GAHAR Handbook:\n{context}\n\n"
                    f"User question: {question}\n\n"
                    "Answer concisely in 3–5 short bullet points."
                )
            )
        )
        
        # Call Gemini
        ai_response = self.gemini_model.invoke(messages)
        
        # Save to history
        self.chat_history.add_user_message(question)
        self.chat_history.add_ai_message(ai_response.content)
        
        return ai_response.content
    
    def _create_fallback_answer(self, question: str, context: str) -> str:
        """
        Create a simple context-based answer when models are unavailable
        
        Args:
            question: User question
            context: Retrieved context
            
        Returns:
            Simple answer
        """
        if not context or context == "No highly relevant context found in the GAHAR handbook.":
            answer = "I couldn't find relevant information in the GAHAR handbook to answer your question."
        else:
            # Extract most relevant part
            snippets = context.split("\n\n---\n\n")
            most_relevant = snippets[0] if snippets else context[:500]
            
            answer = (
                f"Based on the GAHAR handbook:\n\n"
                f"{most_relevant}\n\n"
                f"[Note: This is a context-based response. "
                f"For better answers, ensure XLM or Gemini models are properly configured.]"
            )
        
        # Save to history
        self.chat_history.add_user_message(question)
        self.chat_history.add_ai_message(answer)
        
        return answer
    
    def get_history(self):
        """Return chat history"""
        return self.chat_history.messages
    
    def clear_history(self):
        """Clear chat history"""
        self.chat_history.clear()
        print("✅ Chat history cleared")
    
    def get_statistics(self):
        """Get system statistics"""
        return {
            "session_id": self.session_id,
            "query_decomposition_enabled": self.use_query_decomposition,
            "xlm_available": self.xlm_available,
            "gemini_fallback_available": self.gemini_model is not None,
            "embedding_model": Config.EMBEDDING_MODEL_NAME,
            "llm_model": Config.XLM_MODEL_NAME if self.xlm_available else "Gemini",
            "messages_in_history": len(self.chat_history.messages)
        }


# Console test
if __name__ == "__main__":
    print("🏥 Enhanced GAHAR Assistant - Console Test\n")
    
    assistant = EnhancedGaharAssistant(
        session_id="console-test",
        use_query_decomposition=True,
        use_gemini_fallback=True  # Keep Gemini as backup
    )
    
    print("\n" + "="*80)
    print("Ready! Type 'exit' to quit, 'stats' for statistics, 'clear' to clear history")
    print("="*80 + "\n")
    
    while True:
        try:
            q = input("🧑 You: ").strip()
            
            if not q:
                continue
            
            if q.lower() == "exit":
                print("\n👋 Goodbye!")
                break
            
            if q.lower() == "stats":
                stats = assistant.get_statistics()
                print("\n📊 Statistics:")
                for key, value in stats.items():
                    print(f"   {key}: {value}")
                continue
            
            if q.lower() == "clear":
                assistant.clear_history()
                continue
            
            # Get answer
            ans = assistant.answer(q)
            print(f"\n🤖 Assistant:\n{ans}\n")
            
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}\n")