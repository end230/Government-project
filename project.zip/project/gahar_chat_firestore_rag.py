# gahar_chat_firestore.py

import os
from dotenv import load_dotenv

from langchain_community.chat_message_histories import ChatMessageHistory

from langchain_google_genai import ChatGoogleGenerativeAI

from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

from langchain_core.messages import HumanMessage, SystemMessage

from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader


# ==============================
# CONFIG
# ==============================

PROJECT_ID = "langchain-25e73"          # 🔴 put your real Firebase/GCP project ID
COLLECTION_NAME = "chat_history"
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

SYSTEM_PROMPT = """
You are an expert in the GAHAR (General Authority for Healthcare Accreditation and Regulation) Hospital Standards.
Your job is to answer questions ONLY based on the official GAHAR Handbook content provided in the context below.

Follow these rules strictly:

1️⃣ Use ONLY the provided context
- Do NOT invent or assume information.
- If the answer is not explicitly stated in the context, say:
  "This information is not specified in the provided GAHAR context."

2️⃣ Provide clear, professional, accreditation-level answers
Every answer must be:
- Accurate and concise
- Using formal healthcare accreditation language
- Preferably in 3–5 short bullet points.

3️⃣ When relevant, include:
- Intent
- Key surveyor actions
- Key evidence of compliance
If not available in context, omit them.

4️⃣ Maintain a high level of authority
- Professional, objective, evidence-based
- Consistent with Egyptian hospital accreditation standards

5️⃣ Format the answer cleanly
- Go straight to the point.
- Avoid long paragraphs.
- Do NOT exceed ~100 words unless the user explicitly asks for more detail.

Your task:
Using ONLY the context provided, answer the user’s question as a GAHAR accreditation specialist, briefly and to the point.
"""


# ==============================
# VECTORSTORE (RAG)
# ==============================

def _get_embeddings():
    return HuggingFaceEmbeddings(
        model_name=EMBED_MODEL
    )


def init_vectorstore() -> Chroma:
    """
    Initialize or load the Chroma vector store for gahar.pdf.
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    pdf_path = os.path.join(current_dir, "books", "gahar.pdf")
    db_dir = os.path.join(current_dir, "db")
    persistent_directory = os.path.join(db_dir, "chroma_db")

    os.makedirs(db_dir, exist_ok=True)

    if not os.path.exists(pdf_path):
        raise FileNotFoundError(
            f"PDF file not found at: {pdf_path} "
            f"(make sure 'books/gahar.pdf' exists)."
        )

    embeddings = _get_embeddings()

    if not os.path.exists(persistent_directory):
        print("Vector store does not exist. Building it now...")

        loader = PyPDFLoader(pdf_path)
        documents = loader.load()

        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        docs = text_splitter.split_documents(documents)

        print("\n--- Document Chunks Information ---")
        print(f"Number of document chunks: {len(docs)}")
        print(f"Sample chunk:\n{docs[0].page_content[:400]}\n")

        db = Chroma.from_documents(
            docs,
            embeddings,
            persist_directory=persistent_directory,
        )
        print("\n--- Finished creating vector store ---")
    else:
        print("Vector store already exists. Loading it...")
        db = Chroma(
            persist_directory=persistent_directory,
            embedding_function=embeddings,
        )

    return db


# ==============================
# GAHAR ASSISTANT CLASS
# ==============================

class GaharAssistant:
    """
    Backend assistant:
    - handles RAG over GAHAR
    - stores history in Firestore
    - calls Gemini to answer questions
    """

    def __init__(self, session_id: str = "default-session"):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        load_dotenv(os.path.join(current_dir, ".env"))
            # for GOOGLE_API_KEY etc.

        # Firestore client + history
        self.chat_history = ChatMessageHistory()


        # RAG DB
        self.db = init_vectorstore()

        # LLM
        self.model = ChatGoogleGenerativeAI(model="gemini-2.5-flash")

    def get_history(self):
        """Return the stored chat messages."""
        return self.chat_history.messages

    def answer(self, question: str) -> str:
        """
        Take a user question, run RAG + Gemini, store history, return answer text.
        """

        # 1) Retrieve relevant context from GAHAR
        docs = self.db.similarity_search(question, k=3)

        if not docs:
            context_text = "No highly relevant context found in the GAHAR handbook."
        else:
            context_text = "\n\n---\n\n".join(
                doc.page_content for doc in docs
            )[:4000]

        # 2) Build messages: system + history + current question with context
        messages = []

        messages.append(SystemMessage(content=SYSTEM_PROMPT))

        clean_history = [
            m for m in self.chat_history.messages
            if getattr(m, "content", None) not in (None, "")
        ]
        messages.extend(clean_history)

        messages.append(
            HumanMessage(
                content=(
                    f"Context from GAHAR Handbook:\n{context_text}\n\n"
                    f"User question: {question}\n\n"
                    "Answer concisely in 3–5 short bullet points."
                )
            )
        )

        # 3) Call model
        ai_response = self.model.invoke(messages)

        # 4) Save clean Q & A to Firestore
        self.chat_history.add_user_message(question)
        self.chat_history.add_ai_message(ai_response.content)

        return ai_response.content


# Optional: manual test if you run this file directly
if __name__ == "__main__":
    assistant = GaharAssistant(session_id="console-test")
    while True:
        q = input("User: ")
        if q.lower().strip() == "exit":
            break
        ans = assistant.answer(q)
        print("AI:", ans)
