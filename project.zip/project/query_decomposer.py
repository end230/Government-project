"""
Query Decomposition Module for GAHAR RAG System
Breaks complex queries into simpler sub-queries for better retrieval
"""

import re
from typing import List, Dict


class QueryDecomposer:
    """
    Decompose complex GAHAR-related queries into simpler sub-queries
    """
    
    def __init__(self, max_sub_queries: int = 3):
        """
        Initialize query decomposer
        
        Args:
            max_sub_queries: Maximum number of sub-queries to generate
        """
        self.max_sub_queries = max_sub_queries
        
        # GAHAR-specific keywords that indicate complexity
        self.gahar_keywords = [
            'standard', 'requirement', 'evidence', 'surveyor', 'compliance',
            'intent', 'element', 'criterion', 'indicator', 'documentation',
            'policy', 'procedure', 'protocol', 'guideline', 'regulation'
        ]
    
    def is_complex_query(self, query: str) -> bool:
        """
        Determine if a GAHAR query is complex enough to decompose
        
        Args:
            query: User query
            
        Returns:
            True if query should be decomposed
        """
        query_lower = query.lower()
        
        complexity_indicators = [
            len(query.split()) > 15,  # Long query
            query.count('?') > 1,  # Multiple questions
            ' and ' in query_lower,  # Multiple parts
            ' or ' in query_lower,  # Alternatives
            any(word in query_lower for word in ['also', 'additionally', 'furthermore']),
            query_lower.count('what') + query_lower.count('how') + query_lower.count('which') > 1
        ]
        
        return sum(complexity_indicators) >= 2
    
    def decompose_query(self, query: str) -> Dict:
        """
        Decompose a GAHAR query into sub-queries
        
        Args:
            query: User query about GAHAR standards
            
        Returns:
            Dictionary with original query and sub-queries
        """
        query = query.strip()
        
        # Check if decomposition is needed
        if not self.is_complex_query(query):
            return {
                "original_query": query,
                "is_complex": False,
                "sub_queries": [query],
                "method": "none"
            }
        
        # Decompose the query
        sub_queries = self._rule_based_decomposition(query)
        
        return {
            "original_query": query,
            "is_complex": True,
            "sub_queries": sub_queries,
            "method": "rule_based"
        }
    
    def _rule_based_decomposition(self, query: str) -> List[str]:
        """
        Rule-based decomposition for GAHAR queries
        
        Args:
            query: Complex query
            
        Returns:
            List of sub-queries
        """
        sub_queries = []
        query_lower = query.lower()
        
        # Pattern 1: Split by "and"
        if ' and ' in query_lower:
            parts = re.split(r'\s+and\s+', query, flags=re.IGNORECASE)
            for part in parts:
                part = part.strip()
                if len(part) > 10:  # Only meaningful parts
                    # Add question mark if missing
                    if not part.endswith('?'):
                        part += '?'
                    sub_queries.append(part)
        
        # Pattern 2: Multiple questions
        if '?' in query and query.count('?') > 1:
            questions = [q.strip() + '?' for q in query.split('?') if q.strip()]
            sub_queries.extend(questions)
        
        # Pattern 3: GAHAR-specific patterns
        gahar_patterns = [
            # "What is X and what is Y?" -> ["What is X?", "What is Y?"]
            (r'what\s+(?:is|are)\s+(.+?)\s+and\s+what\s+(?:is|are)\s+(.+?)[\?.]', 
             lambda m: [f"What is {m.group(1)}?", f"What is {m.group(2)}?"]),
            
            # "What are requirements and evidence?" -> ["What are requirements?", "What are evidence?"]
            (r'what\s+(?:is|are)\s+(?:the\s+)?(.+?)\s+and\s+(.+?)[\?.]',
             lambda m: [f"What are {m.group(1)}?", f"What are {m.group(2)}?"]),
            
            # "How to comply and what evidence?" -> ["How to comply?", "What evidence?"]
            (r'how\s+to\s+(.+?)\s+and\s+what\s+(.+?)[\?.]',
             lambda m: [f"How to {m.group(1)}?", f"What {m.group(2)}?"]),
        ]
        
        for pattern, formatter in gahar_patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                sub_queries.extend(formatter(match))
        
        # Pattern 4: Extract key GAHAR components
        if not sub_queries:
            # Look for GAHAR keywords
            found_keywords = [kw for kw in self.gahar_keywords if kw in query_lower]
            if len(found_keywords) >= 2:
                for kw in found_keywords[:2]:
                    sub_queries.append(f"What about {kw} in GAHAR standards?")
        
        # Remove duplicates and limit
        sub_queries = list(dict.fromkeys(sub_queries))[:self.max_sub_queries]
        
        # If no patterns matched, return original
        if not sub_queries:
            return [query]
        
        return sub_queries
    
    def merge_contexts(self, contexts: List[str]) -> str:
        """
        Merge contexts from multiple sub-queries
        
        Args:
            contexts: List of context strings
            
        Returns:
            Merged context
        """
        seen_content = set()
        merged = []
        
        for ctx in contexts:
            if ctx and ctx not in seen_content:
                merged.append(ctx)
                seen_content.add(ctx)
        
        return "\n\n---\n\n".join(merged)


class GAHARQueryExpander:
    """
    Expand GAHAR queries with synonyms and related terms
    """
    
    def __init__(self):
        """Initialize with GAHAR-specific terminology"""
        
        # GAHAR-specific synonyms and related terms
        self.gahar_synonyms = {
            "requirement": ["criteria", "standard", "condition", "mandate"],
            "evidence": ["documentation", "proof", "record", "verification"],
            "compliance": ["adherence", "conformity", "fulfillment", "satisfaction"],
            "surveyor": ["assessor", "evaluator", "inspector", "auditor"],
            "policy": ["guideline", "protocol", "procedure", "directive"],
            "patient": ["individual", "person", "client", "service recipient"],
            "care": ["service", "treatment", "management", "delivery"],
            "quality": ["excellence", "standard", "level", "grade"],
            "safety": ["security", "protection", "safeguarding", "risk management"],
            "accreditation": ["certification", "recognition", "approval", "validation"]
        }
    
    def expand_query(self, query: str, max_expansions: int = 2) -> List[str]:
        """
        Expand GAHAR query with synonyms
        
        Args:
            query: Original query
            max_expansions: Maximum number of expanded queries
            
        Returns:
            List including original and expanded queries
        """
        expanded = [query]
        query_lower = query.lower()
        
        for term, synonyms in self.gahar_synonyms.items():
            if term in query_lower:
                for synonym in synonyms[:max_expansions]:
                    expanded_query = query_lower.replace(term, synonym)
                    if expanded_query != query_lower:
                        expanded.append(expanded_query)
        
        # Remove duplicates and limit
        return list(dict.fromkeys(expanded))[:max_expansions + 1]


# Example usage
if __name__ == "__main__":
    decomposer = QueryDecomposer(max_sub_queries=3)
    
    # Test with GAHAR-specific queries
    test_queries = [
        "What are the requirements for patient safety and what evidence is needed?",
        "How to comply with GAHAR standard 1.1 and what are the surveyor actions?",
        "What is the intent of the infection control standard?",
        "What documentation is required for quality management and patient care?"
    ]
    
    print("🔍 GAHAR Query Decomposition Test\n")
    print("="*80)
    
    for query in test_queries:
        result = decomposer.decompose_query(query)
        print(f"\n📝 Original: {result['original_query']}")
        print(f"❓ Complex: {result['is_complex']}")
        
        if result['is_complex']:
            print(f"🔹 Sub-queries:")
            for i, sq in enumerate(result['sub_queries'], 1):
                print(f"   {i}. {sq}")
        
        print("-"*80)
