"""
Configuration file for Enhanced GAHAR RAG System
Integrates with your existing implementation
"""

import os

class Config:
    """Configuration for GAHAR RAG System"""
    
    # ============================================================================
    # PATHS (matching your existing structure)
    # ============================================================================
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    BOOKS_DIR = os.path.join(CURRENT_DIR, "/content/project/Data")
    DB_DIR = os.path.join(CURRENT_DIR, "/content/project/db")
    CHROMA_DB_PATH = os.path.join(DB_DIR, "chroma_db")
    
    # ============================================================================
    # MODEL SETTINGS - UPGRADED TO MULTILINGUAL GENERATIVE
    # ============================================================================
    
    # Embeddings Model (KEEPING THIS - It is excellent for retrieval)
    EMBEDDING_MODEL_NAME = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"
    
    # LLM Model (SWITCHED to Qwen2.5 for proper chat generation)
    USE_XLM_MODEL = True  # Variable name kept for compatibility, but now uses Qwen
    
    # NEW MODEL: Qwen2.5-7B-Instruct
    # Supports Arabic/English natively and is a "Decoder" (Chat) model.
    XLM_MODEL_NAME = "Qwen/Qwen2.5-1.5B-Instruct" 
    
    # Note: If this is too slow on your PC, switch to "Qwen/Qwen2.5-1.5B-Instruct"
    
    # ============================================================================
    # FINE-TUNING SETTINGS
    # ============================================================================
    FINE_TUNED_MODEL_PATH = os.path.join(CURRENT_DIR, "models", "fine_tuned_qwen")
    USE_FINE_TUNED_MODEL = False  # Set to True after fine-tuning
    
    # LoRA Configuration
    USE_LORA = True
    LORA_R = 16        # Increased for better learning
    LORA_ALPHA = 32    # Standard is 2x Rank
    LORA_DROPOUT = 0.05
    
    # Training parameters
    LEARNING_RATE = 2e-4 # Slightly higher for QLoRA/LoRA usually
    BATCH_SIZE = 4
    NUM_EPOCHS = 3
    MAX_LENGTH = 1024 # Increased for RAG context
    
    # ============================================================================
    # QUERY DECOMPOSITION SETTINGS
    # ============================================================================
    USE_QUERY_DECOMPOSITION = True
    MAX_SUB_QUERIES = 3
    
    # ============================================================================
    # RAG SETTINGS
    # ============================================================================
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200 # Increased overlap slightly for better context continuity
    TOP_K_RETRIEVAL = 4 # Retrieve one extra chunk for better coverage
    
    # Additional RAG improvements
    USE_RERANKING = True
    SIMILARITY_THRESHOLD = 0.5
    USE_MMR = True     # Changed to True to get diverse chunks (avoid duplicates)
    
    # ============================================================================
    # GENERATION SETTINGS
    # ============================================================================
    MAX_NEW_TOKENS = 1024 # Increased to allow full answers
    TEMPERATURE = 0.6     # Slightly lower for more factual answers
    TOP_P = 0.9
    DO_SAMPLE = True
    
    # ============================================================================
    # SYSTEM PROMPT
    # ============================================================================
    SYSTEM_PROMPT = """أنت خبير GAHAR. أجب بناءً على السياق المقدم فقط.
You are a GAHAR expert. Answer based ONLY on the context.
- Arabic questions → Arabic answers
- English questions → English answers""" 
    
    # ============================================================================
    # FIRESTORE SETTINGS
    # ============================================================================
    PROJECT_ID = "langchain-25e73"
    COLLECTION_NAME = "chat_history"
    
    # ============================================================================
    # LANGUAGE SUPPORT
    # ============================================================================
    SUPPORTED_LANGUAGES = ["en", "ar"]
    DEFAULT_LANGUAGE = "en"