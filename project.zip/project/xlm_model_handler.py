"""
XLM Model Handler for GAHAR RAG System
Updated to support Generative Models (Qwen, Llama, etc.)
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from typing import List, Dict, Optional

class XLMModelHandler:
    """
    Handle Generative Models (Qwen/Llama) for GAHAR question answering.
    Note: Class name kept as 'XLMModelHandler' for compatibility with existing code.
    """
    
    def __init__(
        self,
        model_name: str = "Qwen/Qwen2.5-1.5B-Instruct",
        use_fine_tuned: bool = False,
        fine_tuned_path: Optional[str] = None,
        device: Optional[str] = None
    ):
        """
        Initialize Model Handler
        """
        self.model_name = model_name
        self.use_fine_tuned = use_fine_tuned
        self.fine_tuned_path = fine_tuned_path
        
        # Determine device
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        print(f"🤖 Initializing Generative Model Handler")
        print(f"   Device: {self.device}")
        print(f"   Model: {model_name}")
        
        self._load_model()
    
    def _load_model(self):
        """Load the model and tokenizer"""
        try:
            path_to_load = self.fine_tuned_path if (self.use_fine_tuned and self.fine_tuned_path) else self.model_name
            
            print(f"   Loading model from: {path_to_load}...")
            
            # Load Tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(path_to_load)
            
            # Load Model
            self.model = AutoModelForCausalLM.from_pretrained(
                path_to_load,
                torch_dtype="auto",  # Automatically uses float16 or bfloat16
                device_map="auto" if self.device == "cuda" else None,
                trust_remote_code=True
            )
            
            # Ensure padding token exists
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
                
            print("   ✅ Model loaded successfully")
            
        except Exception as e:
            print(f"   ❌ Error loading model: {e}")
            raise
    
    def generate_answer(
        self,
        question: str,
        context: str,
        system_prompt: str,
        max_new_tokens: int = 1024,
        temperature: float = 0.6,
        top_p: float = 0.9
    ) -> str:
        """
        Generate answer using Qwen/Llama with Chat Templates
        """
        # 1. Structure the conversation
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Context from GAHAR Handbook:\n{context}\n\nQuestion: {question}"}
        ]

        # 2. Apply the model's specific chat template (Handles Qwen/Llama formats automatically)
        prompt = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        
        # 3. Tokenize
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=4096  # Adjusted for longer RAG contexts
        ).to(self.model.device)
        
        # 4. Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )
        
        # 5. Decode ONLY the new tokens (the answer)
        # We slice [input_length:] to skip repeating the prompt
        input_length = inputs.input_ids.shape[1]
        generated_tokens = outputs[0][input_length:]
        
        answer = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
        
        return answer.strip()

    def generate_with_chat_history(
        self,
        question: str,
        context: str,
        system_prompt: str,
        chat_history: List[Dict[str, str]],
        max_new_tokens: int = 1024,
        temperature: float = 0.6,
        top_p: float = 0.9
    ) -> str:
        """
        Generate answer with full conversation history
        """
        # 1. Start with system prompt
        messages = [{"role": "system", "content": system_prompt}]
        
        # 2. Add History (Last 4 turns to save context window)
        for msg in chat_history[-4:]:
            role = "user" if msg.get("role") == "user" else "assistant"
            content = msg.get("content", "")
            messages.append({"role": role, "content": content})
            
        # 3. Add Current Question with Context
        messages.append({
            "role": "user", 
            "content": f"Context:\n{context}\n\nQuestion: {question}"
        })

        # 4. Apply Template & Generate
        prompt = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=4096
        ).to(self.model.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )
            
        input_length = inputs.input_ids.shape[1]
        generated_tokens = outputs[0][input_length:]
        answer = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
        
        return answer.strip()

# Simple test block
if __name__ == "__main__":
    print("🧪 Testing Updated Model Handler with Qwen/Llama...")
    try:
        # Note: You can change the model here to test
        handler = XLMModelHandler(model_name="Qwen/Qwen2.5-1.5B-Instruct")
        
        ans = handler.generate_answer(
            question="What is the GAHAR standard for patient safety?",
            context="Standard PSR.1: The hospital must have a patient safety program.",
            system_prompt="You are a helpful assistant."
        )
        print(f"\n✅ Answer: {ans}")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")